import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api";

export default function Appointments() {
  const nav = useNavigate();
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [profiles, setProfiles] = useState(new Map());
  const [waitingAppt, setWaitingAppt] = useState(null);
  const [waitChat, setWaitChat] = useState([]);
  const [waitText, setWaitText] = useState("");
  const [followAppt, setFollowAppt] = useState(null);
  const [fuChat, setFuChat] = useState([]);
  const [fuText, setFuText] = useState("");
  const [fuSymptoms, setFuSymptoms] = useState("");
  const [fuFiles, setFuFiles] = useState([]);
  const [rateAppt, setRateAppt] = useState(null);
  const [rateStars, setRateStars] = useState(0);
  const [rateText, setRateText] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) { nav("/login"); return; }
    const load = async () => {
      setLoading(true);
      setError("");
      try {
        const { data } = await API.get("/appointments/mine");
        const arr = Array.isArray(data) ? data : [];
        setList(arr);
        const ids = Array.from(new Set(arr.map((a) => String(a.doctor?._id || a.doctor || ""))).values()).filter(Boolean);
        if (ids.length) {
          const resps = await Promise.all(ids.map((id) => API.get(`/doctors?user=${id}`).catch(() => ({ data: [] }))));
          const map = new Map();
          ids.forEach((id, idx) => {
            const first = Array.isArray(resps[idx]?.data) ? resps[idx].data[0] : null;
            if (first) map.set(String(id), first);
          });
          setProfiles(map);
        } else {
          setProfiles(new Map());
        }
      } catch (e) {
        setError(e.response?.data?.message || e.message || "Failed to load");
      }
      setLoading(false);
    };
    load();
  }, [nav]);

  useEffect(() => {
    const iv = setInterval(async () => {
      try {
        const ids = Array.from(new Set((list || []).map((a) => String(a.doctor?._id || a.doctor || "")).values())).filter(Boolean);
        if (!ids.length) return;
        const resps = await Promise.all(ids.map((id) => API.get(`/doctors?user=${id}`).catch(() => ({ data: [] }))));
        const map = new Map();
        ids.forEach((id, idx) => {
          const first = Array.isArray(resps[idx]?.data) ? resps[idx].data[0] : null;
          if (first) map.set(String(id), first);
        });
        setProfiles(map);
      } catch (_) {}
    }, 1000);
    return () => clearInterval(iv);
  }, [list]);

  useEffect(() => {
    const cleanup = [];
    const origin = String(API.defaults.baseURL || "").replace(/\/(api)?$/, "");
    const w = window;
    const onReady = () => {
      try {
        const socket = w.io ? w.io(origin, { transports: ["websocket", "polling"] }) : null;
        if (socket) {
          socket.on('doctor:status', (p) => {
            const did = String(p?.doctorId || "");
            if (!did) return;
            setProfiles((prev) => {
              const next = new Map(prev);
              const cur = next.get(did);
              if (cur) next.set(did, { ...cur, isOnline: !!p.isOnline, isBusy: !!p.isBusy });
              return next;
            });
          });
          cleanup.push(() => { try { socket.close(); } catch(_) {} });
        }
      } catch (_) {}
    };
    if (!w.io) {
      const s = document.createElement('script');
      s.src = 'https://cdn.socket.io/4.7.2/socket.io.min.js';
      s.onload = onReady;
      document.body.appendChild(s);
      cleanup.push(() => { try { document.body.removeChild(s); } catch(_) {} });
    } else {
      onReady();
    }
    return () => { cleanup.forEach((fn) => fn()); };
  }, []);

  useEffect(() => {
    const timers = [];
    const now = Date.now();
    (list || []).forEach((a) => {
      if (String(a.status).toUpperCase() !== 'CONFIRMED' || a.type !== 'online') return;
      try {
        const d = new Date(a.date);
        const t = String(a.startTime || '00:00');
        const parts = t.split(":");
        const hh = Number(parts[0]) || 0;
        const mm = Number(parts[1]) || 0;
        d.setHours(hh, mm, 0, 0);
        const alertAt = d.getTime() - 5 * 60 * 1000;
        if (alertAt > now) {
          const key = `alert5min_${a._id}`;
          if (localStorage.getItem(key) === '1') return;
          const tmr = setTimeout(() => {
            alert('Doctor will join in 5 min before appointment');
            localStorage.setItem(key, '1');
          }, alertAt - now);
          timers.push(tmr);
        }
      } catch (_) {}
    });
    return () => { timers.forEach(clearTimeout); };
  }, [list]);

  useEffect(() => {
    if (!waitingAppt) return;
    try {
      const id = String(waitingAppt._id || waitingAppt.id);
      const msgs = JSON.parse(localStorage.getItem(`wr_${id}_chat`) || '[]');
      setWaitChat(Array.isArray(msgs) ? msgs : []);
    } catch(_) { setWaitChat([]); }
  }, [waitingAppt]);

  const cancel = async (id) => {
    try {
      const apptId = id || "";
      await API.put(`/appointments/${String(apptId)}/cancel`);
      setList((prev) => prev.map((x) => (String(x._id) === String(apptId) ? { ...x, status: "CANCELLED" } : x)));
      if (waitingAppt && String(waitingAppt._id) === String(apptId)) setWaitingAppt(null);
    } catch (e) {
      const msg = e.response?.data?.message || e.message || "Cancel failed";
      if (e.response?.status === 404) {
        alert("Appointment not found or already cancelled");
        try {
          const { data } = await API.get("/appointments/mine");
          setList(Array.isArray(data) ? data : []);
        } catch (_) {}
      } else {
        alert(msg);
      }
    }
  };

  const apptStartTs = (a) => {
    try {
      const d = new Date(a.date);
      const [hh, mm] = String(a.startTime || '00:00').split(':').map((x) => Number(x));
      d.setHours(hh, mm, 0, 0);
      return d.getTime();
    } catch (_) { return 0; }
  };

  const canFollowUp = (a) => {
    if (!a || !a.prescriptionText) return false;
    const ts = apptStartTs(a);
    const now = Date.now();
    const diff = now - ts;
    const max = 5 * 24 * 60 * 60 * 1000; // up to 5 days after appointment
    return diff >= 0 && diff <= max;
  };

  const loadFollowData = (id) => {
    const keyBase = `fu_${String(id)}`;
    try {
      const msgs = JSON.parse(localStorage.getItem(`${keyBase}_chat`) || '[]');
      const files = JSON.parse(localStorage.getItem(`${keyBase}_files`) || '[]');
      const symp = String(localStorage.getItem(`${keyBase}_symptoms`) || '');
      setFuChat(Array.isArray(msgs) ? msgs : []);
      setFuFiles(Array.isArray(files) ? files : []);
      setFuSymptoms(symp || "");
    } catch (_) {
      setFuChat([]);
      setFuFiles([]);
      setFuSymptoms("");
    }
  };

  const saveFollowData = (id, msgs, files, symptoms) => {
    const keyBase = `fu_${String(id)}`;
    try {
      localStorage.setItem(`${keyBase}_chat`, JSON.stringify(msgs || []));
      localStorage.setItem(`${keyBase}_files`, JSON.stringify(files || []));
      localStorage.setItem(`${keyBase}_symptoms`, String(symptoms || ''));
    } catch (_) {}
  };

  return (
    <div className="max-w-7xl mx-auto px-4 mt-8">
      <h1 className="text-2xl font-semibold mb-4">My appointments</h1>
      <div className="bg-white border border-slate-200 rounded-xl">
        {loading ? (
          <div className="p-4 text-slate-600">Loading...</div>
        ) : error ? (
          <div className="p-4 text-red-600">{error}</div>
        ) : list.length === 0 ? (
          <div className="p-4 text-slate-600">No appointments found</div>
        ) : (
          <div className="divide-y">
            {list.map((a) => (
              <div key={a._id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {(() => {
                    const docId = String(a.doctor?._id || a.doctor || "");
                    const prof = profiles.get(docId);
                    const img = String((prof?.photoBase64 || a.doctor?.photoBase64 || ""));
                    const hasImg = img.startsWith("data:") || img.startsWith("http");
                    return hasImg ? (
                      <img
                        src={img}
                        alt="Doctor"
                        className="h-14 w-14 rounded-md object-cover border"
                      />
                    ) : (
                      <div className="h-14 w-14 rounded-md border bg-white" />
                    );
                  })()}
                  <div>
                    {(() => {
                      const docId = String(a.doctor?._id || a.doctor || "");
                      const prof = profiles.get(docId);
                      const name = a.doctor?.name ? `Dr. ${a.doctor?.name}` : "";
                      const spec = (prof?.specializations && prof.specializations[0]) || a.doctor?.specializations?.[0] || "";
                      const addr = (prof?.clinic?.address || a.doctor?.clinic?.address || a.doctor?.address || a.doctor?.clinicAddress || a.clinic?.address || a.clinicAddress || "");
                      const isOnline = typeof prof?.isOnline === 'boolean' ? !!prof?.isOnline : null;
                      return (
                        <>
                          <div className="font-semibold">{name}</div>
                          <div className="text-sm text-slate-600 flex items-center gap-2">
                            <span>{spec}</span>
                            {a.type === 'online' && isOnline !== null && (
                              <span className={`inline-block w-2 h-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`} />
                            )}
                          </div>
                          <div className="text-sm text-slate-700">Address: <span className="text-slate-900">{addr}</span></div>
                        </>
                      );
                    })()}
                    <div className="text-sm text-slate-700">Date & Time: <span className="text-slate-900">{`${a.date} | ${a.startTime}`}</span></div>
                    {a.type === 'online' && (() => {
                      const docId = String(a.doctor?._id || a.doctor || "");
                      const prof = profiles.get(docId);
                      const isOnline = typeof prof?.isOnline === 'boolean' ? !!prof?.isOnline : null;
                      const isBusy = typeof prof?.isBusy === 'boolean' ? !!prof?.isBusy : null;
                      if (isOnline === null && isBusy === null) return <div className="text-xs text-slate-600">Status not set</div>;
                      return isOnline && !isBusy
                        ? <div className="text-xs text-green-700">Doctor is online, you can join soon</div>
                        : isBusy
                          ? <div className="text-xs text-amber-700">Doctor is busy, please wait</div>
                          : <div className="text-xs text-slate-600">Doctor may take extra time</div>;
                    })()}
                  </div>
                </div>
                <div className="flex gap-3 items-center">
                  {String(a.status).toUpperCase() === 'CANCELLED' ? (
                    <span className="inline-block text-xs px-2 py-1 rounded bg-red-100 text-red-700">Cancelled</span>
                  ) : String(a.status).toUpperCase() === 'COMPLETED' ? (
                    <div className="flex flex-wrap gap-2 items-center">
                      <span className="inline-block text-xs px-2 py-1 rounded bg-green-100 text-green-700">Consultation Completed</span>
                      {a.prescriptionText && (
                        <button
                          onClick={() => window.open(`/prescription/${a._id || a.id}`, '_blank')}
                          className="border border-indigo-600 text-indigo-700 px-3 py-1 rounded-md"
                        >
                          View Prescription
                        </button>
                      )}
                      <button
                        onClick={() => {
                          const docId = String(a.doctor?._id || a.doctor || '');
                          if (docId) window.open(`/doctor/${docId}`, '_blank');
                        }}
                        className="border border-slate-300 px-3 py-1 rounded-md"
                      >
                        Book Again
                      </button>
                      <button
                        onClick={() => {
                          setRateAppt(a);
                          const key = `rate_${String(a._id || a.id)}`;
                          try {
                            const stars = Number(localStorage.getItem(`${key}_stars`) || 0) || 0;
                            const text = String(localStorage.getItem(`${key}_comment`) || '') || '';
                            setRateStars(stars);
                            setRateText(text);
                          } catch(_) { setRateStars(0); setRateText(''); }
                        }}
                        className="border border-green-600 text-green-700 px-3 py-1 rounded-md"
                      >
                        Rate Doctor
                      </button>
                    </div>
                  ) : (
                    <>
                      {a.type === 'online' && String(a.status).toUpperCase() === 'CONFIRMED' && (
                        <>
                          <button
                            onClick={() => {
                              const docId = String(a.doctor?._id || a.doctor || '');
                              const prof = profiles.get(docId);
                              const isOnline = typeof prof?.isOnline === 'boolean' ? !!prof?.isOnline : false;
                              const isBusy = typeof prof?.isBusy === 'boolean' ? !!prof?.isBusy : false;
                              if (!isOnline) { alert('Sorry, doctor is offline. Please book the next available slot.'); return; }
                              if (isBusy) { alert('Sorry, doctor is busy at the moment. Please wait or try later.'); return; }
                              const url = String(a.meetingLink || '').includes('meet.google.com') ? a.meetingLink : 'https://meet.google.com/new';
                              window.open(url, '_blank');
                            }}
                            className="border border-green-600 text-green-700 px-3 py-1 rounded-md"
                          >
                            Join Meeting
                          </button>
                          {(() => {
                            try {
                              const d = new Date(a.date);
                              const [hh, mm] = String(a.startTime || '00:00').split(':').map((x) => Number(x));
                              d.setHours(hh, mm, 0, 0);
                              const diff = d.getTime() - Date.now();
                              const withinWindow = diff <= 10 * 60 * 1000 && diff > 0; // 5–10 min window
                              if (!withinWindow) return null;
                              return (
                                <button
                                  onClick={() => setWaitingAppt(a)}
                                  className="border border-indigo-600 text-indigo-700 px-3 py-1 rounded-md"
                                >
                                  Join Waiting Room
                                </button>
                              );
                            } catch (_) { return null; }
                          })()}
                        </>
                      )}
                      
                      <button
                        onClick={() => nav(`/pay/${a._id}`)}
                        className="border border-slate-300 px-3 py-1 rounded-md"
                      >
                        Pay Online
                      </button>
                      <button
                        onClick={() => cancel(a._id || a.id)}
                        disabled={!a?._id}
                        className={`border px-3 py-1 rounded-md ${(!a?._id) ? 'border-slate-200 text-slate-400 cursor-not-allowed' : 'border-slate-300'}`}
                      >
                        Cancel appointment
                      </button>
                      {a.prescriptionText && (
                        <>
                          <button
                            onClick={() => window.open(`/prescription/${a._id || a.id}`, '_blank')}
                            className="border border-indigo-600 text-indigo-700 px-3 py-1 rounded-md"
                          >
                            View Prescription
                          </button>
                          <button
                            onClick={() => window.open(`/prescription/${a._id || a.id}?print=1`, '_blank')}
                            className="border border-slate-300 px-3 py-1 rounded-md"
                          >
                            Download PDF
                          </button>
                          <button
                            onClick={async () => {
                              const url = `${window.location.origin}/prescription/${a._id || a.id}`;
                              try { await navigator.clipboard.writeText(url); alert('Link copied for pharmacy'); } catch(_) {}
                            }}
                            className="border border-slate-300 px-3 py-1 rounded-md"
                          >
                            Share to pharmacy
                          </button>
                          <button
                            onClick={async () => {
                              const url = `${window.location.origin}/prescription/${a._id || a.id}`;
                              try { await navigator.clipboard.writeText(url); alert('Link copied for lab tests'); } catch(_) {}
                            }}
                            className="border border-slate-300 px-3 py-1 rounded-md"
                          >
                            Share for lab tests
                          </button>
                          {canFollowUp(a) && (
                            <button
                              onClick={() => { setFollowAppt(a); loadFollowData(a._id || a.id); }}
                              className="border border-green-600 text-green-700 px-3 py-1 rounded-md"
                            >
                              Follow-up Chat
                            </button>
                          )}
                        </>
                      )}
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="mt-8">
        <div className="grid md:grid-cols-3 gap-8 items-start">
          <div>
            <div className="flex items-center gap-2 text-indigo-700 font-semibold text-lg">Prescripto</div>
            <p className="mt-3 text-slate-600 text-sm">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
          </div>
          <div>
            <div className="font-semibold text-slate-900 mb-2">COMPANY</div>
            <div className="space-y-1 text-slate-700 text-sm">
              <Link to="/" className="hover:text-indigo-700">Home</Link>
              <div>
                <Link to="/about" className="hover:text-indigo-700">About us</Link>
              </div>
              <div className="text-slate-700">Delivery</div>
              <div className="text-slate-700">Privacy policy</div>
            </div>
          </div>
          <div>
            <div className="font-semibold text-slate-900 mb-2">GET IN TOUCH</div>
            <div className="text-slate-700 text-sm">+1-212-456-7890</div>
            <div className="text-slate-700 text-sm">greatstackdev@gmail.com</div>
          </div>
        </div>
        <hr className="my-6 border-slate-200" />
        <div className="text-center text-slate-600 text-sm">Copyright 2024 © Prescripto.com - All Right Reserved.</div>
      </div>
      {waitingAppt && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl border border-slate-200 w-[95vw] max-w-2xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="font-semibold text-slate-900">Waiting Room</div>
              <button
                onClick={() => setWaitingAppt(null)}
                className="px-3 py-1 rounded-md border border-slate-300"
              >
                Leave
              </button>
            </div>
            <div className="p-4">
              <div className="text-slate-700 text-sm">Appointment: <span className="text-slate-900">{waitingAppt.date} {waitingAppt.startTime}-{waitingAppt.endTime}</span></div>
              <div className="mt-2 text-indigo-700">Waiting for doctor to join…</div>
              <div className="mt-4">
                <div className="text-slate-900 font-semibold mb-2">Chat</div>
                <div className="h-28 overflow-y-auto border border-slate-200 rounded-md p-2 bg-slate-50">
                  {waitChat.length === 0 ? (
                    <div className="text-slate-600 text-sm">No messages</div>
                  ) : (
                    waitChat.map((m, idx) => (
                      <div key={idx} className="text-sm text-slate-700">{m}</div>
                    ))
                  )}
                </div>
                <div className="mt-2 flex gap-2">
                  <input
                    value={waitText}
                    onChange={(e) => setWaitText(e.target.value)}
                    placeholder="Type a quick message"
                    className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm"
                  />
                  <button
                    onClick={() => {
                      if (waitText.trim()) {
                        const id = String(waitingAppt._id || waitingAppt.id);
                        const next = [...waitChat, waitText.trim()];
                        setWaitChat(next);
                        try { localStorage.setItem(`wr_${id}_chat`, JSON.stringify(next)); } catch(_) {}
                        setWaitText("");
                      }
                    }}
                    className="px-3 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    Send
                  </button>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <button
                  onClick={() => cancel(waitingAppt._id || waitingAppt.id)}
                  className="px-3 py-2 rounded-md border border-red-600 text-red-700"
                >
                  Cancel appointment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {followAppt && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl border border-slate-200 w-[95vw] max-w-2xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="font-semibold text-slate-900">Free Follow-up (5 days)</div>
              <button
                onClick={() => setFollowAppt(null)}
                className="px-3 py-1 rounded-md border border-slate-300"
              >
                Close
              </button>
            </div>
            <div className="p-4">
              <div className="text-slate-700 text-sm">Appointment: <span className="text-slate-900">{followAppt.date} {followAppt.startTime}-{followAppt.endTime}</span></div>
              <div className="mt-4 grid grid-cols-1 gap-3">
                <div>
                  <div className="text-slate-900 font-semibold mb-1">Upload symptoms</div>
                  <textarea
                    value={fuSymptoms}
                    onChange={(e) => setFuSymptoms(e.target.value)}
                    rows={3}
                    className="w-full border border-slate-300 rounded-md p-3 text-sm"
                    placeholder="Describe your current symptoms"
                  />
                </div>
                <div>
                  <div className="text-slate-900 font-semibold mb-1">Ask doubts</div>
                  <div className="h-28 overflow-y-auto border border-slate-200 rounded-md p-2 bg-slate-50">
                    {fuChat.length === 0 ? (
                      <div className="text-slate-600 text-sm">No messages yet</div>
                    ) : (
                      fuChat.map((m, idx) => (
                        <div key={idx} className="text-sm text-slate-700">{m}</div>
                      ))
                    )}
                  </div>
                  <div className="mt-2 flex gap-2">
                    <input
                      value={fuText}
                      onChange={(e) => setFuText(e.target.value)}
                      placeholder="Type your question"
                      className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm"
                    />
                    <button
                      onClick={() => {
                        if (fuText.trim()) {
                          const next = [...fuChat, fuText.trim()];
                          setFuChat(next);
                          saveFollowData(followAppt._id || followAppt.id, next, fuFiles, fuSymptoms);
                          setFuText("");
                        }
                      }}
                      className="px-3 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white"
                    >
                      Send
                    </button>
                  </div>
                </div>
                <div>
                  <div className="text-slate-900 font-semibold mb-1">Send reports</div>
                  <input
                    type="file"
                    multiple
                    onChange={async (e) => {
                      const files = Array.from(e.target.files || []);
                      const newItems = [];
                      for (const f of files) {
                        try {
                          const buf = await f.arrayBuffer();
                          const bytes = new Uint8Array(buf);
                          let binary = '';
                          for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
                          const b64 = btoa(binary);
                          const mime = f.type || 'application/octet-stream';
                          newItems.push({ name: f.name, url: `data:${mime};base64,${b64}` });
                        } catch (_) {}
                      }
                      const nextFiles = [...fuFiles, ...newItems];
                      setFuFiles(nextFiles);
                      saveFollowData(followAppt._id || followAppt.id, fuChat, nextFiles, fuSymptoms);
                      e.target.value = '';
                    }}
                  />
                  <div className="mt-2 space-y-2">
                    {fuFiles.length === 0 ? (
                      <div className="text-slate-600 text-sm">No reports uploaded</div>
                    ) : (
                      fuFiles.map((f, idx) => (
                        <div key={idx} className="flex items-center justify-between border rounded-md p-2">
                          <div className="text-sm text-slate-700 truncate">{f.name}</div>
                          <div className="flex items-center gap-2">
                            <button onClick={() => window.open(f.url, '_blank')} className="px-2 py-1 rounded-md border border-slate-300 text-sm">Open</button>
                            <button
                              onClick={() => {
                                const nextFiles = fuFiles.filter((_, i) => i !== idx);
                                setFuFiles(nextFiles);
                                saveFollowData(followAppt._id || followAppt.id, fuChat, nextFiles, fuSymptoms);
                              }}
                              className="px-2 py-1 rounded-md border border-red-600 text-red-700 text-sm"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => { saveFollowData(followAppt._id || followAppt.id, fuChat, fuFiles, fuSymptoms); alert('Saved'); }}
                    className="px-3 py-2 rounded-md border border-slate-300"
                  >
                    Save
                  </button>
                  <div className="text-xs text-slate-600">Doctor replies here; video call requires new booking.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {rateAppt && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl border border-slate-200 w-[95vw] max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="font-semibold text-slate-900">Rate Doctor</div>
              <button
                onClick={() => setRateAppt(null)}
                className="px-3 py-1 rounded-md border border-slate-300"
              >
                Close
              </button>
            </div>
            <div className="p-4">
              <div className="text-slate-700 text-sm mb-2">Doctor: <span className="text-slate-900">{rateAppt.doctor?.name || ''}</span></div>
              <div className="flex items-center gap-2 mb-3">
                {[1,2,3,4,5].map((n) => (
                  <button
                    key={n}
                    onClick={() => setRateStars(n)}
                    className={`h-8 w-8 rounded-full border flex items-center justify-center ${rateStars >= n ? 'bg-yellow-300 border-yellow-400' : 'bg-white border-slate-300'}`}
                  >
                    ★
                  </button>
                ))}
              </div>
              <textarea
                value={rateText}
                onChange={(e) => setRateText(e.target.value)}
                rows={4}
                className="w-full border border-slate-300 rounded-md p-3 text-sm"
                placeholder="Write your feedback"
              />
              <div className="mt-3 flex items-center gap-2">
                <button
                  onClick={() => {
                    const key = `rate_${String(rateAppt._id || rateAppt.id)}`;
                    try {
                      localStorage.setItem(`${key}_stars`, String(rateStars || 0));
                      localStorage.setItem(`${key}_comment`, String(rateText || ''));
                      alert('Thanks for your rating');
                    } catch(_) {}
                    setRateAppt(null);
                  }}
                  className="px-3 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                  Submit
                </button>
                <div className="text-xs text-slate-600">Your rating is saved on this device.</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}